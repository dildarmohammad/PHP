<?php
require('fpdf.php');

$pdf = new FPDF();

$pdf->addPage('L');
$pdf->SetFont('Arial','',10);

//random number

session_start();

// Initialize the starting number if it is not set in the session
if (!isset($_SESSION['random_number'])) {
    $_SESSION['random_number'] = 5446000;    
}

// Get the current random number
$random_number = $_SESSION['random_number'];

// Display the current number
//echo "Auto increment number $random_number";

// Increment the number for the next request
$_SESSION['random_number']++;

//random number end

$pdf->Cell(140,10,'Receipt Number:',1); $pdf->Cell (140,10,$random_number,1);

$pdf->Ln();

$pdf->Ln();

$pdf->Output('receipt.pdf','I'); 

    
?>