<form action="#" method="POST" name="team" class="team" id="main-team">

<input type="text" class="formgroup" name="Name" value="" placeholder="Full Name">

<input type="tel" class="formgroup" name="Phone" value="" placeholder="Phone">

<input type="email" class="formgroup" name="Email" value="" placeholder="Email Id">

<input type="text" class="formgroup" name="City" value="" placeholder="City">

<input type="submit" class="formgroup" name="submit" value="submit">

</form>


<?php

// Report errors during development
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

// Database connection (Make sure to replace with your database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "team"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if(isset($_POST['submit'])) {

    // Sanitize user input to avoid SQL injection
    $Name = $conn->real_escape_string($_POST['Name']);
    $Phone = $conn->real_escape_string($_POST['Phone']);
    $Email = $conn->real_escape_string($_POST['Email']);    
    $City = $conn->real_escape_string($_POST['City']);

    // Prepare the SQL query with placeholders
    $sql = "INSERT INTO employee (Name, Phone, Email, City) VALUES ('$Name', '$Phone', '$Email', '$City')";

    // Initialize prepared statement
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('MySQL prepare failed: ' . $conn->error);
    }

    // Bind parameters to the query
    //$stmt->bind_param('ssss', $Name, $Phone, $Email, $City);

    // Execute the query
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the prepared statement and connection
    $stmt->close();
}

// Close connection
$conn->close();
?>
