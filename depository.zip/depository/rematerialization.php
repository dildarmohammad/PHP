<?php

require_once('fpdf/fpdf.php');
require_once('fpdi/src/autoload.php');

// Create instance of FPDI
$pdf = new \setasign\Fpdi\Fpdi();

// Set source PDF file (make sure the file exists at the given path)
$pageCount = $pdf->setSourceFile('file:///C:/xampp/htdocs/depository/rematerializationform.pdf');

// Import the first page
$pageId = $pdf->importPage(1, \setasign\Fpdi\PdfReader\PageBoundaries::MEDIA_BOX);

// Add a new page
$pdf->addPage();

// Use the imported page, and adjust the coordinates and scaling if needed
$pdf->useImportedPage($pageId, 10, 10, 190); // Adjust size if necessary

// Output the generated PDF to the browser
$pdf->Output('I', 'generated.pdf');
?>
